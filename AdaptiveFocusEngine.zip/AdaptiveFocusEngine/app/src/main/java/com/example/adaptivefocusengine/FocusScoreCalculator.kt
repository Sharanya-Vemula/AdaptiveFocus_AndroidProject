package com.example.adaptivefocusengine

object FocusScoreCalculator {

    fun calculate(durationMinutes: Int, interruptions: Int): Int {
        val base = durationMinutes * 4
        val penalty = interruptions * 5
        return (base - penalty).coerceIn(0, 100)
    }
}