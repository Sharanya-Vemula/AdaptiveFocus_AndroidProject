package com.example.adaptivefocusengine

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.adaptivefocusengine.FocusDatabase
import com.example.adaptivefocusengine.FocusSession
import com.example.adaptivefocusengine.FocusRepository
import kotlinx.coroutines.launch

class FocusViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FocusRepository

    // Backing property for sessions history
    private val _sessions = MutableLiveData<List<FocusSession>>()
    val sessions: LiveData<List<FocusSession>> = _sessions

    init {
        val dao = FocusDatabase.getDatabase(application).focusDao()
        repository = FocusRepository(dao)
        loadSessions() // load history at startup
    }

    /**
     * Save a focus session into Room database
     */
    fun saveSession(session: FocusSession) {
        viewModelScope.launch {
            repository.saveSession(session)
            loadSessions() // refresh history after insert
        }
    }

    /**
     * Load all focus sessions for history screen
     */
    fun loadSessions() {
        viewModelScope.launch {
            _sessions.postValue(repository.getSessions())
        }
    }
}