package com.example.adaptivefocusengine

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [FocusSession::class], version = 1)
abstract class FocusDatabase : RoomDatabase() {

    abstract fun focusDao(): FocusDao

    companion object {
        @Volatile private var INSTANCE: FocusDatabase? = null

        fun getDatabase(context: Context): FocusDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    FocusDatabase::class.java,
                    "focus_db"
                ).build().also { INSTANCE = it }
            }
    }
}