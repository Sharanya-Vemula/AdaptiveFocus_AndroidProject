package com.example.adaptivefocusengine

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.adaptivefocusengine.FocusSession
import com.example.adaptivefocusengine.databinding.ItemSessionBinding

class SessionAdapter : RecyclerView.Adapter<SessionAdapter.ViewHolder>() {

    private val sessions = mutableListOf<FocusSession>()

    fun submitList(list: List<FocusSession>) {
        sessions.clear()
        sessions.addAll(list)
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ItemSessionBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemSessionBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val session = sessions[position]
        holder.binding.sessionText.text =
            "Focus Score: ${session.focusScore}"
    }

    override fun getItemCount() = sessions.size
}