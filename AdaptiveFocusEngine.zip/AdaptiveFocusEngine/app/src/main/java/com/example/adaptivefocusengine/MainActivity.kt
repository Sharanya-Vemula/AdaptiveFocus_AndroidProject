package com.example.adaptivefocusengine

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.adaptivefocusengine.FocusSession
import com.example.adaptivefocusengine.databinding.ActivityMainBinding
import com.example.adaptivefocusengine.SessionAdapter
import com.example.adaptivefocusengine.FocusScoreCalculator
import com.example.adaptivefocusengine.FocusViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: FocusViewModel by viewModels()
    private val sessionAdapter = SessionAdapter()

    private var startTime = 0L
    private var elapsedTime = 0L
    private var isRunning = false

    private val handler = Handler(Looper.getMainLooper())

    private val timerRunnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                elapsedTime += 1000

                val minutes = (elapsedTime / 60000)
                val seconds = (elapsedTime % 60000) / 1000

                binding.timerText.text =
                    String.format("%02d:%02d", minutes, seconds)

                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        observeViewModel()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        binding.sessionRecycler.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = sessionAdapter
        }
    }

    private fun observeViewModel() {
        viewModel.sessions.observe(this) { sessions ->
            sessionAdapter.submitList(sessions)
        }
    }

    private fun setupClickListeners() {

        binding.startButton.setOnClickListener {
            startTime = System.currentTimeMillis()
            elapsedTime = 0L
            isRunning = true
            handler.post(timerRunnable)

            Toast.makeText(this, "Session Started", Toast.LENGTH_SHORT).show()
        }

        binding.pauseButton.setOnClickListener {
            isRunning = false
            Toast.makeText(this, "Session Paused", Toast.LENGTH_SHORT).show()
        }

        binding.resumeButton.setOnClickListener {
            if (!isRunning) {
                isRunning = true
                handler.post(timerRunnable)
                Toast.makeText(this, "Session Resumed", Toast.LENGTH_SHORT).show()
            }
        }

        binding.stopButton.setOnClickListener {
            isRunning = false

            val endTime = System.currentTimeMillis()
            val durationMinutes = (elapsedTime / 60000).toInt()
            val interruptions = 2 // demo value

            val score = FocusScoreCalculator.calculate(
                durationMinutes,
                interruptions
            )

            val session = FocusSession(
                startTime = startTime,
                endTime = endTime,
                interruptions = interruptions,
                focusScore = score
            )

            viewModel.saveSession(session)

            showSessionSummary(durationMinutes, score)

            elapsedTime = 0L
            binding.timerText.text = "00:00"
        }
    }

    private fun showSessionSummary(duration: Int, score: Int) {
        AlertDialog.Builder(this)
            .setTitle("Session Summary")
            .setMessage(
                "Duration: $duration minutes\n" +
                        "Focus Score: $score"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(timerRunnable)
    }
}