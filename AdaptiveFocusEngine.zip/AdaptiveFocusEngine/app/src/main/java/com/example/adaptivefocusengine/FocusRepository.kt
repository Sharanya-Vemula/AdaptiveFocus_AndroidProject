package com.example.adaptivefocusengine

import com.example.adaptivefocusengine.FocusDao
import com.example.adaptivefocusengine.FocusSession

class FocusRepository(private val dao: FocusDao) {

    suspend fun saveSession(session: FocusSession) {
        dao.insertSession(session)
    }

    suspend fun getSessions(): List<FocusSession> = dao.getAllSessions()
}